# Image Mosaicing

Image mosaicing project for a Computer Vision course (EECE5639)

## Usage

Install dependencies and run:

```python
python pano.py
```

The directory for the images being used can be changed in the main method.
